<nav class="navbar navbar-default header-navigation stricky">
  <div class="container"> 
    
    <!-- Brand and toggle get grouped for better mobile display -->
    
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#main-nav-bar" aria-expanded="false"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <a class="navbar-brand" href="<?=base_url();?>"> <img src="<?=base_url();?>assets/img/logo.png" alt="Awesome Image" height="71"/> </a> </div>
    
    <!-- Collect the nav links, forms, and other content for toggling -->
    
    <div class="collapse navbar-collapse" id="main-nav-bar">
      <ul class="nav navbar-nav navigation-box">
        <li><a href="http://antworksmoney.com/">Home</a></li>
        <li> <a href="#">About Us</a>
          <ul class="sub-menu">            
            <div class="menu_one">
              <li class="m1"><a href="#">CORPORATE PROFILE</a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </li>
              <li class="m1"> <a href="#">TEAM</a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </li>
              <li class="m1"> <a href="#">VISION</a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </li>
              <li class="m1"><a href="#">BRAND PROFILE</a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </li>
            </div>
          </ul>
          <!-- /.sub-menu --> 
          
        </li>
        <li> <a href="">Services</a>
          <ul class="sub-menu">
            <div class="menu_one">
              <li class="m1"><a href="http://p2ploan.antworksmoney.com/">PEER TO PEER LOAN</a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </li>
              <li class="m1"> <a href="#">BANK BAZAAR</a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </li>
              <li class="m1"> <a href="#">CREDIT COUNCELLING</a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </li>
              <li class="m1"><a href="#">LOAN PROPOSAL LISTING</a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </li>
              <li class="m1"> <a href="#">LOAN PROPOSAL BIDDING</a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </li>
              <li class="m1"><a href="">INVESTMENT SERVICES</a>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </li>
            </div>
          </ul>
          <!-- /.sub-menu --> 
          
        </li>
        <li> <a href="#">MONEY TALK</a>
          <ul class="sub-menu">
            <li><a href="http://antworksmoney.com/blog/">Blog</a></li>
            <li><a href="http://antworksmoney.com/blog/forum/">Forum</a></li>
          </ul>
          <!-- /.sub-menu --> 
          
        </li>
        <li><a href="#">NETWORK</a></li>
        <li><a href="http://antworksmoney.com/blog/contact/">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right right-box">
        <li> <a href="#"><span class="phone-only">Search</span><i class="fa fa-search"></i></a>
          <div class="sub-menu search-box">
            <form action="#" class="clearfix">
              <input type="text" placeholder="Search Here" />
              <button type="submit"><i class="fa fa-search"></i></button>
            </form>
          </div>
          <!-- /.sub-menu --> 
          
        </li>
        <li> <a role="button" data-toggle="collapse" href="#sidebarCollapse" aria-expanded="false" aria-controls="sidebarCollapse"><span class="phone-only">Side Menu</span><i class="fa fa-bars"></i></a> </li>
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
    
  </div>
  <!-- /.container --> 
  
</nav>
</header>
<!-- /.header -->