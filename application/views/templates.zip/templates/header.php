<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Antworks Money</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?=base_url();?>assets/css/build.css">
<link rel="stylesheet" href="<?=base_url();?>assets/css/style.css">
<link rel="stylesheet" href="<?=base_url();?>assets/css/responsive.css">
<link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/jquery-ui.css">

<? if($p2p=='P2P')
{?>

<link href="<?=base_url();?>assets/css/materialize.css" rel="stylesheet">
<link href="<?=base_url();?>assets/css/materialize.forms.css" rel="stylesheet">
<link href="<?=base_url();?>assets/css/jquery.datetimepicker.css" rel="stylesheet">
<? }?>

<script src="http://code.jquery.com/jquery-latest.min.js"></script>
</head>
<body>
<header class="header header-fixed header-1">
<div class="header-top">
  <div class="container">
    <div class="right-info pull-right">
      <ul class="list-inline">
        <li> <span> <i class="fa fa-user"></i> User name : Logged in </span> </li>
        <li> <span> <i class="fa fa-envelope"></i> connect@antworksmoney.com </span> </li>
        <li>
          <ul class="list-inline social">
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
          </ul>
          <!-- /.social --> 
        </li>
      </ul>
    </div>
    <!-- /.right-info --> 
  </div>
</div>
<!-- /.header-top --> 

